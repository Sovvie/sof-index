"use strict";

// The Authentik API token is per person and per machine, so it lives with the
// rest of sof's secrets in ~/.sof/affine.env (owner-only permissions), never in
// sof.toml. SOF_AFFINE_TOKEN overrides it, for CI.

const fs = require("fs");
const os = require("os");
const path = require("path");

const ENV_VAR = "SOF_AFFINE_TOKEN";
const FILE_KEY = "AFFINE_TOKEN";

function sofHome() {
  return process.env.SOF_HOME ? path.resolve(process.env.SOF_HOME) : path.join(os.homedir(), ".sof");
}

function tokenFilePath() {
  return path.join(sofHome(), "affine.env");
}

function readTokenFile() {
  const filePath = tokenFilePath();
  if (!fs.existsSync(filePath)) {
    return null;
  }
  for (const line of fs.readFileSync(filePath, "utf8").split(/\r?\n/)) {
    const match = line.match(/^\s*([A-Z_]+)\s*=\s*(.*?)\s*$/);
    if (match && match[1] === FILE_KEY && match[2]) {
      return match[2].replace(/^(["'])(.*)\1$/, "$2");
    }
  }
  return null;
}

// Returns { token, source } or null.
function resolveToken() {
  const fromEnv = (process.env[ENV_VAR] || "").trim();
  if (fromEnv) {
    return { token: fromEnv, source: `$${ENV_VAR}` };
  }
  const fromFile = readTokenFile();
  if (fromFile) {
    return { token: fromFile, source: tokenFilePath() };
  }
  return null;
}

function requireToken() {
  const resolved = resolveToken();
  if (!resolved) {
    throw new Error(`No AFFiNE bridge token set. Run: sof run affine login  (or set $${ENV_VAR})`);
  }
  return resolved.token;
}

function saveToken(token) {
  const value = String(token || "").trim();
  if (!value) {
    throw new Error("Token is empty.");
  }
  if (/\s/.test(value)) {
    throw new Error("Token must not contain whitespace.");
  }

  const filePath = tokenFilePath();
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  // Remove first so an existing file's looser mode is not kept (writeFile's
  // mode only applies on create).
  fs.rmSync(filePath, { force: true });
  fs.writeFileSync(filePath, `# Written by sof run affine login - do not commit or share\n${FILE_KEY}=${value}\n`, {
    encoding: "utf8",
    mode: 0o600,
  });
  return filePath;
}

function deleteToken() {
  const filePath = tokenFilePath();
  if (!fs.existsSync(filePath)) {
    return null;
  }
  fs.rmSync(filePath);
  return filePath;
}

module.exports = { ENV_VAR, tokenFilePath, resolveToken, requireToken, saveToken, deleteToken };
