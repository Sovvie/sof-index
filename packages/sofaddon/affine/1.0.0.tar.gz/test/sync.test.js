"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("fs");
const http = require("http");
const os = require("os");
const path = require("path");

const { runAffine } = require("../src/commands/affine");

const TOKEN = "test-token";

const tables = {
  "ws1:weapons": {
    title: "Weapons",
    columns: [
      { id: "a", name: "Name", type: "title" },
      { id: "b", name: "Damage", type: "number" },
      { id: "c", name: "Stars", type: "variable" },
    ],
    rows: [
      { Name: "Sword", Damage: 10, Stars: { variable: "MaxStars", value: 9, reference: "{{Variables.MaxStars}}" } },
      { Name: "Bow", Damage: 4, Stars: { variable: "Missing", reference: "{{Variables.Missing}}" } },
      { Name: "", Damage: 0 },
    ],
  },
  "ws1:list": {
    title: "Spawn Points",
    columns: [{ id: "x", name: "X", type: "number" }],
    rows: [{ X: 1 }, { X: 2 }],
  },
};

function startBridge() {
  const server = http.createServer((req, res) => {
    if (req.headers.authorization !== `Bearer ${TOKEN}`) {
      res.writeHead(401).end("unauthorized");
      return;
    }
    const match = req.url.match(/^\/database\/(.+)$/);
    const table = match && tables[decodeURIComponent(match[1])];
    if (!table) {
      res.writeHead(404).end("no such table");
      return;
    }
    res.writeHead(200, { "Content-Type": "application/json" }).end(JSON.stringify(table));
  });
  return new Promise((resolve) => server.listen(0, "127.0.0.1", () => resolve(server)));
}

// Runs the command with console output captured.
async function run(argv) {
  const lines = [];
  const saved = { log: console.log, warn: console.warn, error: console.error };
  console.log = console.warn = console.error = (...args) => lines.push(args.join(" "));
  const exitBefore = process.exitCode;
  process.exitCode = undefined;
  try {
    await runAffine(argv);
    return { output: lines.join("\n"), exitCode: process.exitCode ?? 0 };
  } finally {
    Object.assign(console, saved);
    process.exitCode = exitBefore;
  }
}

test("sync, status and hand-edit detection against a mock bridge", async (t) => {
  const server = await startBridge();
  t.after(() => server.close());

  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "sof-affine-"));
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  process.env.SOF_AFFINE_TOKEN = TOKEN;
  t.after(() => delete process.env.SOF_AFFINE_TOKEN);

  const config = path.join(dir, "sof.toml");
  fs.writeFileSync(
    config,
    `[affine]
workspace = "ws1"
bridge = "http://127.0.0.1:${server.address().port}"

[[affine.sync]]
table = "weapons"
output = "src/Data/Weapons.luau"

[[affine.sync]]
table = "ws1:list"
output = "src/Data/SpawnPoints.luau"
`
  );
  const weapons = path.join(dir, "src/Data/Weapons.luau");
  const spawns = path.join(dir, "src/Data/SpawnPoints.luau");

  // Parser picked up by name, next to its output.
  fs.mkdirSync(path.dirname(weapons), { recursive: true });
  fs.writeFileSync(
    path.join(dir, "src/Data/Weapons.parser.js"),
    `module.exports = { transform(data, ctx) { data.Sword.Title = ctx.title; return data; } };`
  );

  let result = await run(["sync", config]);
  assert.equal(result.exitCode, 0, result.output);
  assert.match(result.output, /unresolved variable reference .*\{\{Variables\.Missing\}\}/);
  assert.match(result.output, /1 blank row\(s\) skipped/);

  const text = fs.readFileSync(weapons, "utf8");
  assert.match(text, /^-- Synced from AFFiNE \("Weapons"\)/);
  assert.match(text, /\n-- affine-sync: table=ws1:weapons source=[0-9a-f]{16} output=[0-9a-f]{16}\n/);
  assert.match(text, /-- Shaped by src\/Data\/Weapons.parser.js/);
  assert.match(text, /\["Stars"\] = 9,/);
  assert.match(text, /\["Title"\] = "Weapons",/);
  assert.doesNotMatch(text, /Missing/);

  // No title column: an ordered array.
  assert.match(fs.readFileSync(spawns, "utf8"), /return \{\n\t\{\n\t\t\["X"\] = 1,\n\t\},/);

  result = await run(["sync", config]);
  assert.match(result.output, /unchanged 2/);

  result = await run(["status", config, "--check"]);
  assert.equal(result.exitCode, 0, result.output);
  assert.match(result.output, /All 2 output\(s\) are up to date/);

  // CRLF from a git checkout is not a hand-edit.
  fs.writeFileSync(spawns, fs.readFileSync(spawns, "utf8").replace(/\n/g, "\r\n"));
  result = await run(["status", config, "--offline"]);
  assert.doesNotMatch(result.output, /edited since last sync/);

  // A real hand-edit is.
  fs.appendFileSync(weapons, "-- tweak\n");
  result = await run(["status", config, "--check"]);
  assert.equal(result.exitCode, 1);
  assert.match(result.output, /edited since last sync/);

  // Upstream moves on.
  tables["ws1:weapons"].rows[0].Damage = 12;
  result = await run(["status", config, "--only", "Weapons"]);
  assert.match(result.output, /newer version available/);

  result = await run(["sync", config, "--only", "Weapons"]);
  assert.match(result.output, /hand-edited since the last sync - overwriting/);
  assert.match(fs.readFileSync(weapons, "utf8"), /\["Damage"\] = 12,/);
});

test("sync refuses to clobber a file it did not write", async (t) => {
  const server = await startBridge();
  t.after(() => server.close());
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "sof-affine-"));
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  process.env.SOF_AFFINE_TOKEN = TOKEN;
  t.after(() => delete process.env.SOF_AFFINE_TOKEN);

  const config = path.join(dir, "sof.toml");
  fs.writeFileSync(
    config,
    `[affine]\nbridge = "http://127.0.0.1:${server.address().port}"\n\n[[affine.sync]]\ntable = "ws1:list"\noutput = "Hand.luau"\n`
  );
  fs.writeFileSync(path.join(dir, "Hand.luau"), "return { handWritten = true }\n");

  let result = await run([config]);
  assert.equal(result.exitCode, 1);
  assert.match(result.output, /not written by affine sync/);
  assert.equal(fs.readFileSync(path.join(dir, "Hand.luau"), "utf8"), "return { handWritten = true }\n");

  result = await run([config, "--force"]);
  assert.equal(result.exitCode, 0, result.output);
});

test("a token in sof.toml is rejected", async (t) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "sof-affine-"));
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  const config = path.join(dir, "sof.toml");
  fs.writeFileSync(config, `[affine]\ntoken = "oops"\n`);
  await assert.rejects(runAffine(["status", config, "--offline"]), /remove it from sof.toml/);
});

test("a bad token gets a login hint", async (t) => {
  const server = await startBridge();
  t.after(() => server.close());
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "sof-affine-"));
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  process.env.SOF_AFFINE_TOKEN = "wrong";
  t.after(() => delete process.env.SOF_AFFINE_TOKEN);

  const config = path.join(dir, "sof.toml");
  fs.writeFileSync(
    config,
    `[affine]\nbridge = "http://127.0.0.1:${server.address().port}"\n\n[[affine.sync]]\ntable = "ws1:list"\noutput = "A.luau"\n`
  );
  const result = await run([config]);
  assert.equal(result.exitCode, 1);
  assert.match(result.output, /HTTP 401.*sof run affine login/);
});
