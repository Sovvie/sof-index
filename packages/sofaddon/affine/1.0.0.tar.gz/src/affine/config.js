"use strict";

// Reads the [affine] section of sof.toml:
//
//   [affine]
//   workspace = "<workspaceId>"          # default for tables given as a bare block id
//   bridge = "https://roblox-sync.sov.gg" # optional
//
//   [[affine.sync]]
//   table = "<blockId>"                  # or "<workspaceId>:<blockId>"
//   output = "src/ReplicatedStorage/Data/Weapons.luau"
//   parser = "affine/Weapons.parser.js"  # optional

const fs = require("fs");
const path = require("path");
const toml = require("smol-toml");

const { DEFAULT_BRIDGE_URL } = require("./bridge");

// A parser next to its output is picked up without configuration, the way the
// plugin picks up an AffineParser child: Weapons.luau -> Weapons.parser.js.
const PARSER_SUFFIXES = [".parser.js", ".parser.cjs", ".parser.mjs"];

function autoParserPaths(outputPath) {
  const stem = outputPath.replace(/\.(luau|lua)$/i, "");
  return PARSER_SUFFIXES.map((suffix) => stem + suffix);
}

function nonEmptyString(value) {
  return typeof value === "string" && value.trim() !== "";
}

function resolveTableId(rawTable, defaultWorkspace, label) {
  if (!nonEmptyString(rawTable)) {
    throw new Error(`${label}: "table" is required (a block id, or "<workspaceId>:<blockId>").`);
  }
  const table = rawTable.trim();
  if (table.includes(":")) {
    const [workspace, block] = table.split(":");
    if (!workspace || !block || table.split(":").length !== 2) {
      throw new Error(`${label}: "table" must look like "<workspaceId>:<blockId>", got "${table}".`);
    }
    return table;
  }
  if (!defaultWorkspace) {
    throw new Error(
      `${label}: "table" is a bare block id, so [affine] needs a "workspace" (or write it as "<workspaceId>:<blockId>").`
    );
  }
  return `${defaultWorkspace}:${table}`;
}

function readAffineConfig(configPathArg) {
  const configPath = path.resolve(configPathArg || "sof.toml");
  if (!fs.existsSync(configPath)) {
    throw new Error(`Config file does not exist: ${configPath}`);
  }

  let parsed;
  try {
    parsed = toml.parse(fs.readFileSync(configPath, "utf8"));
  } catch (err) {
    throw new Error(`Failed to parse TOML config at ${configPath}: ${err.message}`);
  }

  const section = parsed.affine;
  if (!section || typeof section !== "object" || Array.isArray(section)) {
    throw new Error(`${configPath} has no [affine] section. See: sof run affine --help`);
  }

  // sof.toml is committed; the token must never live there.
  for (const key of ["token", "api_token", "apiToken", "api_key", "apiKey"]) {
    if (key in section) {
      throw new Error(
        `[affine] has a "${key}" key - remove it from ${path.basename(configPath)} and rotate the token if it was committed. ` +
          `Tokens are stored per machine with: sof run affine login`
      );
    }
  }

  const configDirectory = path.dirname(configPath);
  const defaultWorkspace = nonEmptyString(section.workspace) ? section.workspace.trim() : null;
  const bridge = nonEmptyString(section.bridge) ? section.bridge.trim() : DEFAULT_BRIDGE_URL;

  const rawEntries = section.sync ?? [];
  if (!Array.isArray(rawEntries)) {
    throw new Error(`[affine] "sync" must be an array of tables - write each one as [[affine.sync]].`);
  }

  const seenOutputs = new Map();
  const entries = rawEntries.map((raw, index) => {
    const label = `[[affine.sync]] entry #${index + 1}`;
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      throw new Error(`${label}: entry must be a TOML table.`);
    }
    if (!nonEmptyString(raw.output)) {
      throw new Error(`${label}: "output" is required (path of the .luau file to write).`);
    }

    const tableId = resolveTableId(raw.table, defaultWorkspace, label);
    const outputPath = path.resolve(configDirectory, raw.output.trim());

    const key = outputPath.toLowerCase();
    if (seenOutputs.has(key)) {
      throw new Error(`${label}: "output" ${raw.output} is already written by entry #${seenOutputs.get(key)}.`);
    }
    seenOutputs.set(key, index + 1);

    let parserPath = null;
    let parserExplicit = false;
    if (raw.parser !== undefined) {
      if (!nonEmptyString(raw.parser)) {
        throw new Error(`${label}: "parser" must be a non-empty path when provided.`);
      }
      parserPath = path.resolve(configDirectory, raw.parser.trim());
      parserExplicit = true;
    } else {
      parserPath = autoParserPaths(outputPath).find((candidate) => fs.existsSync(candidate)) || null;
    }

    return {
      index: index + 1,
      tableId,
      output: raw.output.trim(),
      outputPath,
      parserPath,
      parserExplicit,
    };
  });

  return { configPath, configDirectory, bridge, defaultWorkspace, entries };
}

module.exports = { readAffineConfig, autoParserPaths, resolveTableId };
