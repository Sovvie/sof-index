"use strict";

// Client for the roblox-sync bridge. AFFiNE has no API that returns block
// content as JSON, so the bridge decodes it server-side; it sits behind
// Authentik, so requests carry an Authentik API token.

const DEFAULT_BRIDGE_URL = "https://roblox-sync.sov.gg";

class BridgeError extends Error {
  constructor(message, status = null) {
    super(message);
    this.status = status;
  }
}

function createBridge(baseUrl, token) {
  const root = baseUrl.replace(/\/+$/, "");

  async function get(route) {
    let response;
    try {
      response = await fetch(`${root}${route}`, {
        headers: { Authorization: `Bearer ${token}`, Accept: "application/json" },
      });
    } catch (err) {
      const cause = err.cause && err.cause.message ? `: ${err.cause.message}` : "";
      throw new BridgeError(`request to ${root} failed${cause}`);
    }

    const text = await response.text();
    if (!response.ok) {
      const detail = text.trim().slice(0, 300);
      const hint =
        response.status === 401 || response.status === 403
          ? " - is your token valid? Run: sof run affine login"
          : "";
      throw new BridgeError(`bridge returned HTTP ${response.status}${detail ? `: ${detail}` : ""}${hint}`, response.status);
    }

    try {
      return JSON.parse(text);
    } catch (err) {
      throw new BridgeError(`bridge response was not valid JSON: ${err.message}`);
    }
  }

  return {
    url: root,
    // "<workspaceId>:<blockId>"
    fetchTable: (tableId) => get(`/database/${tableId}`),
    fetchWorkspaces: async () => (await get("/workspaces")).workspaces || [],
    fetchDatabases: async (workspaceId) =>
      (await get(`/workspace/${encodeURIComponent(workspaceId)}/databases`)).databases || [],
  };
}

module.exports = { DEFAULT_BRIDGE_URL, BridgeError, createBridge };
