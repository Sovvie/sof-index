"use strict";

// Turns a bridge payload into the Luau source to write. Same shaping rules as
// the AffineSync Studio plugin: variable cells are unwrapped to their resolved
// value, rows are keyed by the title column when there is one, and a custom
// parser (a JS module here, an AffineParser ModuleScript there) gets the last
// word.

const { fingerprint, isPlainObject, serializeLuau } = require("./luau");

// Marks the provenance line the CLI adds under the header. The Studio plugin
// keeps the same facts in attributes on the ModuleScript; a file has nowhere
// else to keep them that survives a fresh clone.
const META_PREFIX = "-- affine-sync:";

function looksLikeVariableReference(text) {
  return typeof text === "string" && /^\s*\{\{.+\}\}\s*$/.test(text);
}

// A "variable" column holds a live reference to a row of a Variables database
// block. The bridge resolves it server-side and sends
//   { "variable": "MaxStars", "value": 9, "reference": "{{Variables.MaxStars}}" }
// Returns [resolvedValue, unresolvedReferenceText].
function unwrapCellValue(value) {
  if (isPlainObject(value)) {
    if (value.reference != null || value.variable != null) {
      if (value.value == null) {
        return [null, String(value.reference ?? value.variable)];
      }
      return [value.value, null];
    }
    return [value, null];
  }

  // Raw "{{Group.Name}}" text means the bridge handed the reference back
  // unresolved; keep it, but say so.
  if (looksLikeVariableReference(value)) {
    return [value, value];
  }

  return [value, null];
}

function normalizeRows(rows) {
  const normalized = [];
  const unresolved = [];

  (Array.isArray(rows) ? rows : []).forEach((row, index) => {
    const outRow = {};
    for (const [key, value] of Object.entries(row || {})) {
      const [resolved, unresolvedRef] = unwrapCellValue(value);
      if (unresolvedRef != null) {
        unresolved.push(`row ${index + 1}, column "${key}": ${unresolvedRef}`);
      }
      if (resolved != null) {
        outRow[key] = resolved;
      }
    }
    normalized.push(outRow);
  });

  return { normalized, unresolved };
}

function findTitleColumnName(columns) {
  const column = (Array.isArray(columns) ? columns : []).find((col) => col && col.type === "title");
  return column ? column.name : null;
}

// With a title column the rows become a map keyed by title; without one they
// stay an ordered array. Blank-titled rows (AFFiNE keeps trailing blank rows)
// are dropped.
function buildData(payload, normalizedRows) {
  const titleColumnName = findTitleColumnName(payload.columns);
  if (titleColumnName == null) {
    return { data: normalizedRows, skippedRows: 0 };
  }

  const data = {};
  let skippedRows = 0;
  for (const row of normalizedRows) {
    const key = row[titleColumnName];
    if (key == null || key === "") {
      skippedRows += 1;
      continue;
    }
    const rest = {};
    for (const [k, v] of Object.entries(row)) {
      if (k !== titleColumnName) {
        rest[k] = v;
      }
    }
    data[String(key)] = rest;
  }
  return { data, skippedRows };
}

// Digest of the fields that make up the table's content, not any per-request
// metadata the bridge may add. Matches the plugin's AffineSourceFingerprint.
function upstreamFingerprint(payload) {
  return fingerprint({ title: payload.title, columns: payload.columns, rows: payload.rows });
}

function remoteVersionOf(payload) {
  for (const key of ["version", "updatedAt", "updated", "lastModified", "revision"]) {
    const value = payload[key];
    if (typeof value === "string" || typeof value === "number") {
      return String(value);
    }
  }
  return null;
}

function displayTitleOf(payload, tableId) {
  const title = payload.title;
  if (typeof title !== "string" || title === "") {
    return tableId;
  }
  // Collapse whitespace so a multi-line title stays inside its comment.
  return title.replace(/\s+/g, " ");
}

// Output digest over the file minus its provenance line, with line endings
// normalized so a git autocrlf checkout does not read as a hand-edit.
function bodyFingerprint(source) {
  const body = source
    .replace(/\r\n/g, "\n")
    .split("\n")
    .filter((line) => !line.startsWith(META_PREFIX))
    .join("\n");
  return fingerprint(body);
}

function formatMeta({ tableId, source, output }) {
  return `${META_PREFIX} table=${tableId} source=${source} output=${output}`;
}

function parseMeta(fileText) {
  const line = fileText
    .replace(/\r\n/g, "\n")
    .split("\n")
    .find((l) => l.startsWith(META_PREFIX));
  if (!line) {
    return null;
  }
  const meta = {};
  for (const match of line.slice(META_PREFIX.length).matchAll(/(\w+)=(\S+)/g)) {
    meta[match[1]] = match[2];
  }
  return meta;
}

// parser: optional { label, transform } where transform(data, context) may be
// async. Returns { source, upstream, info }.
async function buildSource(payload, tableId, { parser = null, outputPath = null } = {}) {
  const { normalized, unresolved } = normalizeRows(payload.rows);
  let { data, skippedRows } = buildData(payload, normalized);

  if (parser) {
    try {
      data = await parser.transform(data, {
        raw: payload,
        title: payload.title,
        columns: payload.columns,
        rows: normalized,
        tableId,
        output: outputPath,
        unresolvedVariables: unresolved,
      });
    } catch (err) {
      throw new Error(`${parser.label} errored: ${err && err.stack ? err.stack : err}`);
    }
  }

  const title = displayTitleOf(payload, tableId);
  const upstream = upstreamFingerprint(payload);

  const lines = [`-- Synced from AFFiNE ("${title}") - do not hand-edit, changes will be overwritten`];
  if (parser) {
    lines.push(`-- Shaped by ${parser.label}`);
  }
  const body = `${lines.join("\n")}\nreturn ${serializeLuau(data)}\n`;
  const output = bodyFingerprint(body);

  // The provenance line goes second so the familiar header stays on top.
  const [firstLine, ...rest] = body.split("\n");
  const source = [firstLine, formatMeta({ tableId, source: upstream, output }), ...rest].join("\n");

  return {
    source,
    upstream,
    info: {
      unresolved,
      skippedRows,
      usedParser: Boolean(parser),
      rowCount: normalized.length,
      title,
      remoteVersion: remoteVersionOf(payload),
    },
  };
}

module.exports = {
  META_PREFIX,
  unwrapCellValue,
  normalizeRows,
  buildData,
  upstreamFingerprint,
  remoteVersionOf,
  bodyFingerprint,
  parseMeta,
  buildSource,
};
