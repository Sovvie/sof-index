"use strict";

// Luau serialization and fingerprinting, ported from the AffineSync Studio
// plugin. The fingerprint must stay bit-for-bit identical to the plugin's
// (canonical string -> two FNV-1a passes), so a table synced from the CLI and
// one synced in Studio agree on whether upstream has changed.

// Depth cap for walking decoded payloads and parser results, so a cyclic or
// absurdly nested value errors with a clear message instead of overflowing.
const MAX_DEPTH = 64;

// Luau compares strings bytewise; JS's default sort compares UTF-16 code units,
// which disagrees for characters outside the BMP.
function compareBytes(a, b) {
  return Buffer.compare(Buffer.from(a, "utf8"), Buffer.from(b, "utf8"));
}

function isNil(value) {
  return value === null || value === undefined;
}

function isPlainObject(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

// The keys a Luau table built from this object would have. A nil value is no
// key at all in Luau, so it is left out here too.
function presentKeys(obj) {
  return Object.keys(obj).filter((k) => !isNil(obj[k]));
}

// A JSON array only becomes a Luau sequence when it has no holes; JSONDecode
// turns a null element into a missing key.
function isSequence(value) {
  return Array.isArray(value) && value.length > 0 && value.every((v) => !isNil(v));
}

// Luau string.format("%q"), byte for byte, so a module reads the same whether
// the plugin or the CLI wrote it: quote and backslash escaped, a newline as a
// backslash followed by a real newline, \r and \0 escaped, the rest raw.
function quoteString(str) {
  let out = '"';
  for (const ch of str) {
    if (ch === '"' || ch === "\\" || ch === "\n") {
      out += "\\" + ch;
    } else if (ch === "\r") {
      out += "\\r";
    } else if (ch === "\0") {
      out += "\\000";
    } else {
      out += ch;
    }
  }
  return out + '"';
}

// Luau tostring(number): the same shortest round-trip digits as JS, but with
// at least two exponent digits (1e-07) and a signed zero. NaN and infinity
// cannot come from JSON, only from a parser; Luau would print them as bare
// nan/inf, which do not parse, so they are written as expressions instead.
function formatNumber(n) {
  if (Number.isNaN(n)) {
    return "0/0";
  }
  if (!Number.isFinite(n)) {
    return n > 0 ? "math.huge" : "-math.huge";
  }
  if (Object.is(n, -0)) {
    return "-0";
  }
  return String(n).replace(/e([+-])(\d)$/, "e$10$2");
}

function serializeValue(value, indent, depth) {
  if (isNil(value)) {
    return "nil";
  }
  switch (typeof value) {
    case "string":
      return quoteString(value);
    case "number":
      return formatNumber(value);
    case "boolean":
      return String(value);
    case "object":
      return serializeTable(value, indent, depth);
    default:
      throw new Error(`cannot serialize value of type ${typeof value}`);
  }
}

// Arrays are written with array syntax so a title-less table round-trips as a
// real Luau array; everything else is a map with sorted, quoted keys.
function serializeTable(value, indent = 1, depth = 0) {
  if (depth > MAX_DEPTH) {
    throw new Error(`table nests deeper than ${MAX_DEPTH} levels (cyclic value returned by a parser?)`);
  }

  const pad = "\t".repeat(indent);
  const closePad = "\t".repeat(indent - 1);

  if (Array.isArray(value)) {
    if (value.length === 0) {
      return "{}";
    }
    const lines = value.map((item) => `${pad}${serializeValue(item, indent + 1, depth + 1)},\n`);
    return `{\n${lines.join("")}${closePad}}`;
  }

  const keys = presentKeys(value).sort(compareBytes);
  if (keys.length === 0) {
    return "{}";
  }
  const lines = keys.map(
    (k) => `${pad}[${quoteString(k)}] = ${serializeValue(value[k], indent + 1, depth + 1)},\n`
  );
  return `{\n${lines.join("")}${closePad}}`;
}

function serializeLuau(value) {
  return serializeValue(value, 1, 0);
}

// C's %.17g, which the plugin uses so the digest does not depend on how a
// number happens to be printed. 17 significant digits, trailing zeros dropped,
// exponent form outside 1e-4 <= |n| < 1e17.
function formatG17(n) {
  if (Number.isNaN(n)) {
    return n > 0 ? "nan" : "-nan";
  }
  if (!Number.isFinite(n)) {
    return n > 0 ? "inf" : "-inf";
  }
  if (n === 0) {
    return Object.is(n, -0) ? "-0" : "0";
  }

  const [mantissa, expText] = n.toExponential(16).split("e");
  const exponent = Number(expText);

  if (exponent < -4 || exponent >= 17) {
    const trimmed = mantissa.includes(".") ? mantissa.replace(/\.?0+$/, "") : mantissa;
    const sign = exponent < 0 ? "-" : "+";
    return `${trimmed}e${sign}${String(Math.abs(exponent)).padStart(2, "0")}`;
  }

  const fixed = n.toFixed(16 - exponent);
  return fixed.includes(".") ? fixed.replace(/\.?0+$/, "") : fixed;
}

function byteLength(str) {
  return Buffer.byteLength(str, "utf8");
}

function canonicalize(value, depth = 0) {
  if (depth > MAX_DEPTH) {
    throw new Error(`value nests deeper than ${MAX_DEPTH} levels`);
  }
  if (isNil(value)) {
    return "z";
  }

  switch (typeof value) {
    case "boolean":
      return value ? "T" : "F";
    case "number":
      return "N" + formatG17(value);
    case "string":
      return `S${byteLength(value)}:${value}`;
    case "object":
      break;
    default:
      return "U" + String(value);
  }

  if (isSequence(value)) {
    return `A${value.length}[${value.map((v) => canonicalize(v, depth + 1) + ",").join("")}]`;
  }

  // A holey array is keyed by its 1-based indices, as Luau would see it.
  const entries = Array.isArray(value)
    ? value.map((v, i) => [String(i + 1), v]).filter(([, v]) => !isNil(v))
    : presentKeys(value).map((k) => [k, value[k]]);
  entries.sort((a, b) => compareBytes(a[0], b[0]));

  const parts = entries.map(([k, v]) => `S${byteLength(k)}:${k}=${canonicalize(v, depth + 1)},`);
  return `M${entries.length}{${parts.join("")}}`;
}

// FNV-1a, 32 bits at a time, over the UTF-8 bytes. Math.imul keeps the
// multiply exact where the plugin has to split it to stay inside 2^53.
function fnv1a32(bytes, basis) {
  let hash = basis >>> 0;
  for (const byte of bytes) {
    hash = Math.imul(hash ^ byte, 16777619) >>> 0;
  }
  return hash;
}

function fingerprint(value) {
  const bytes = Buffer.from(canonicalize(value), "utf8");
  const hex = (h) => h.toString(16).padStart(8, "0");
  return hex(fnv1a32(bytes, 2166136261)) + hex(fnv1a32(bytes, 2654435761));
}

module.exports = {
  MAX_DEPTH,
  isPlainObject,
  quoteString,
  serializeLuau,
  formatG17,
  canonicalize,
  fingerprint,
};
