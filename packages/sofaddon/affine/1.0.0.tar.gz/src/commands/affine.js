"use strict";

const fs = require("fs");
const path = require("path");
const { pathToFileURL } = require("url");

const { readAffineConfig, autoParserPaths } = require("../affine/config");
const { DEFAULT_BRIDGE_URL, createBridge } = require("../affine/bridge");
const { buildSource, bodyFingerprint, parseMeta, upstreamFingerprint, remoteVersionOf } = require("../affine/transform");
const { ENV_VAR, tokenFilePath, requireToken, saveToken, deleteToken } = require("../affine/token");

const FETCH_CONCURRENCY = 4;

const HELP_TEXT = `
sof run affine - Sync AFFiNE database blocks into Luau modules

USAGE:
  sof run affine [sync] [config] [--only <match>] [--force]
  sof run affine status [config] [--offline] [--check]
  sof run affine login [--token-stdin] [--no-verify] [--bridge <url>]
  sof run affine logout
  sof run affine workspaces
  sof run affine databases [workspaceId] [--toml]
  sof run affine parser <output.luau> [config]

COMMANDS:
  sync          Fetch every [[affine.sync]] table and write its .luau file (default)
  status        Show whether each output is synced, hand-edited, or behind AFFiNE
  login         Store your Authentik API token for the bridge on this machine
  logout        Delete the stored token
  workspaces    List the workspaces your token can see
  databases     List the database blocks in a workspace (default: [affine] workspace)
  parser        Create a starter parser next to an output (<name>.parser.js)

OPTIONS:
  config              Path to sof.toml (default: ./sof.toml)
  --only <match>      Only entries whose output path or table id contains <match> (repeatable)
  --force             Overwrite an output file that was not written by affine sync
  --offline           status: skip the network, only report local state
  --check             status: exit with code 1 unless every output is up to date
  --token-stdin       login: read the token from stdin instead of prompting
  --no-verify         login: save without checking the token against the bridge
  --toml              databases: print ready-to-paste [[affine.sync]] entries
  -h, --help          Show this help message

CONFIG (sof.toml):
  [affine]
  workspace = "<workspaceId>"          # default for tables given as a bare block id
  # bridge = "${DEFAULT_BRIDGE_URL}"

  [[affine.sync]]
  table = "<blockId>"                  # or "<workspaceId>:<blockId>"
  output = "src/ReplicatedStorage/Data/Weapons.luau"
  # parser = "affine/Weapons.parser.js"  (default: Weapons.parser.js next to the output)

TOKEN:
  Stored in ${tokenFilePath()} (owner-only), never in sof.toml.
  $${ENV_VAR} takes precedence, for CI.
`;

const SUBCOMMANDS = new Set(["sync", "status", "login", "logout", "workspaces", "databases", "parser"]);

function parseArgs(argv) {
  const args = {
    command: "sync",
    positional: [],
    only: [],
    force: false,
    offline: false,
    check: false,
    tokenStdin: false,
    verify: true,
    toml: false,
    bridge: null,
    help: false,
  };

  let rest = argv;
  if (rest[0] && SUBCOMMANDS.has(rest[0])) {
    args.command = rest[0];
    rest = rest.slice(1);
  }

  for (let i = 0; i < rest.length; i++) {
    const arg = rest[i];
    const takeValue = () => {
      const value = rest[++i];
      if (value === undefined || value.startsWith("-")) {
        throw new Error(`${arg} needs a value.`);
      }
      return value;
    };

    switch (arg) {
      case "-h":
      case "--help":
        args.help = true;
        break;
      case "--only":
        args.only.push(takeValue());
        break;
      case "--force":
        args.force = true;
        break;
      case "--offline":
        args.offline = true;
        break;
      case "--check":
        args.check = true;
        break;
      case "--token-stdin":
        args.tokenStdin = true;
        break;
      case "--no-verify":
        args.verify = false;
        break;
      case "--toml":
        args.toml = true;
        break;
      case "--bridge":
        args.bridge = takeValue();
        break;
      default:
        if (arg.startsWith("-")) {
          throw new Error(`Unknown option: ${arg}`);
        }
        args.positional.push(arg);
    }
  }

  return args;
}

function relative(configDirectory, filePath) {
  return path.relative(configDirectory, filePath).split(path.sep).join("/");
}

function selectEntries(config, only) {
  if (only.length === 0) {
    return config.entries;
  }
  const entries = config.entries.filter((entry) =>
    only.some((match) => entry.output.includes(match) || entry.tableId.includes(match))
  );
  if (entries.length === 0) {
    throw new Error(`No [[affine.sync]] entry matches ${only.map((m) => `"${m}"`).join(", ")}.`);
  }
  return entries;
}

// Fetches each distinct table once, a few at a time. Returns Map<tableId, { payload } | { error }>.
async function fetchTables(bridge, tableIds) {
  const results = new Map();
  const queue = [...new Set(tableIds)];
  const worker = async () => {
    while (queue.length > 0) {
      const tableId = queue.shift();
      try {
        results.set(tableId, { payload: await bridge.fetchTable(tableId) });
      } catch (error) {
        results.set(tableId, { error });
      }
    }
  };
  await Promise.all(Array.from({ length: Math.min(FETCH_CONCURRENCY, queue.length) }, worker));
  return results;
}

// A parser exports function(data, context), or an object with a transform
// (or parse) function; CommonJS and ES modules both work.
async function loadParser(entry, configDirectory) {
  if (!entry.parserPath) {
    return null;
  }
  const label = relative(configDirectory, entry.parserPath);
  if (!fs.existsSync(entry.parserPath)) {
    throw new Error(`parser ${label} does not exist`);
  }

  let mod;
  try {
    mod = await import(pathToFileURL(entry.parserPath).href);
  } catch (err) {
    throw new Error(`failed to load parser ${label}: ${err && err.stack ? err.stack : err}`);
  }

  for (const candidate of [mod.default, mod]) {
    if (typeof candidate === "function") {
      return { label, transform: candidate };
    }
    if (candidate && typeof candidate === "object") {
      const fn = candidate.transform || candidate.parse;
      if (typeof fn === "function") {
        return { label, transform: fn };
      }
    }
  }
  throw new Error(`parser ${label} must export a function(data, context), or an object with a transform function`);
}

function readFileIfExists(filePath) {
  return fs.existsSync(filePath) ? fs.readFileSync(filePath, "utf8") : null;
}

function normalizeNewlines(text) {
  return text.replace(/\r\n/g, "\n");
}

// What can be told about an output without a network call.
function localState(entry, existing) {
  if (existing === null) {
    return { state: "missing" };
  }
  const meta = parseMeta(existing);
  if (!meta || !meta.output) {
    return { state: "foreign" };
  }
  const edited = bodyFingerprint(existing) !== meta.output;
  if (meta.table !== entry.tableId) {
    return { state: "relinked", meta, edited };
  }
  return { state: edited ? "hand-edited" : "synced", meta, edited };
}

async function runSync(args) {
  const config = readAffineConfig(args.positional[0]);
  const entries = selectEntries(config, args.only);
  if (entries.length === 0) {
    console.log(`No [[affine.sync]] entries in ${config.configPath}.`);
    return;
  }

  const bridge = createBridge(config.bridge, requireToken());
  const fetched = await fetchTables(
    bridge,
    entries.map((e) => e.tableId)
  );

  let synced = 0;
  let unchanged = 0;
  let failed = 0;

  for (const entry of entries) {
    const name = entry.output;
    const fail = (message) => {
      failed += 1;
      console.error(`  x ${name}: ${message}`);
    };

    const result = fetched.get(entry.tableId);
    if (result.error) {
      fail(`failed to fetch ${entry.tableId}: ${result.error.message}`);
      continue;
    }

    let built;
    try {
      const parser = await loadParser(entry, config.configDirectory);
      built = await buildSource(result.payload, entry.tableId, { parser, outputPath: entry.outputPath });
    } catch (err) {
      fail(`failed to build source: ${err.message}`);
      continue;
    }

    const existing = readFileIfExists(entry.outputPath);
    const local = localState(entry, existing);

    if (local.state === "foreign" && !args.force) {
      fail("file exists but was not written by affine sync - rerun with --force to overwrite it");
      continue;
    }

    for (const detail of built.info.unresolved) {
      console.warn(`  ! ${name}: unresolved variable reference (${detail})`);
    }

    if (existing !== null && normalizeNewlines(existing) === built.source) {
      unchanged += 1;
      console.log(`  = ${name} (up to date)`);
      continue;
    }

    if (local.edited) {
      console.warn(`  ! ${name}: had been hand-edited since the last sync - overwriting`);
    }

    try {
      fs.mkdirSync(path.dirname(entry.outputPath), { recursive: true });
      fs.writeFileSync(entry.outputPath, built.source, "utf8");
    } catch (err) {
      fail(`failed to write: ${err.message}`);
      continue;
    }

    const extras = [];
    if (built.info.usedParser) {
      extras.push(`via ${relative(config.configDirectory, entry.parserPath)}`);
    }
    if (built.info.skippedRows > 0) {
      extras.push(`${built.info.skippedRows} blank row(s) skipped`);
    }
    synced += 1;
    console.log(
      `  + ${name} (${built.info.rowCount} rows${extras.length ? `, ${extras.join(", ")}` : ""}) from "${built.info.title}"`
    );
  }

  const total = entries.length;
  console.log(`\nSynced ${synced}, unchanged ${unchanged}, failed ${failed} of ${total} table(s).`);
  if (failed > 0) {
    process.exitCode = 1;
  }
}

async function runStatus(args) {
  const config = readAffineConfig(args.positional[0]);
  const entries = selectEntries(config, args.only);
  if (entries.length === 0) {
    console.log(`No [[affine.sync]] entries in ${config.configPath}.`);
    return;
  }

  let fetched = null;
  if (!args.offline) {
    const bridge = createBridge(config.bridge, requireToken());
    fetched = await fetchTables(
      bridge,
      entries.map((e) => e.tableId)
    );
  }

  let notCurrent = 0;
  for (const entry of entries) {
    const existing = readFileIfExists(entry.outputPath);
    const local = localState(entry, existing);
    const editedSuffix = local.edited ? " - edited since last sync" : "";
    let line;
    let current = false;

    if (local.state === "missing") {
      line = "never synced";
    } else if (local.state === "foreign") {
      line = "exists but was not written by affine sync (sync needs --force)";
    } else if (local.state === "relinked") {
      line = `was synced from ${local.meta.table}, now points at ${entry.tableId} - sync to update${editedSuffix}`;
    } else if (!fetched) {
      line = `synced, not checked${editedSuffix}`;
      current = !local.edited;
    } else {
      const result = fetched.get(entry.tableId);
      if (result.error) {
        line = `check failed: ${result.error.message}`;
      } else if (upstreamFingerprint(result.payload) !== local.meta.source) {
        const version = remoteVersionOf(result.payload);
        line = `newer version available${version ? ` (${version})` : ""}${editedSuffix}`;
      } else {
        // Upstream is unchanged; the output can still differ if the parser changed.
        let rebuilt = null;
        try {
          const parser = await loadParser(entry, config.configDirectory);
          rebuilt = await buildSource(result.payload, entry.tableId, { parser, outputPath: entry.outputPath });
        } catch (err) {
          line = `up to date upstream, but the parser failed: ${err.message}`;
        }
        if (rebuilt) {
          if (rebuilt.source === normalizeNewlines(existing)) {
            line = "up to date";
            current = true;
          } else if (local.edited) {
            line = "up to date upstream - edited since last sync";
          } else {
            line = "up to date upstream, but the parser output changed - sync to update";
          }
        }
      }
    }

    if (!current) {
      notCurrent += 1;
    }
    const parserNote = entry.parserPath ? `  [${relative(config.configDirectory, entry.parserPath)}]` : "";
    console.log(`  ${current ? "=" : "!"} ${entry.output}${parserNote}\n      ${line}`);
  }

  console.log(
    notCurrent === 0
      ? `\nAll ${entries.length} output(s) are up to date.`
      : `\n${notCurrent} of ${entries.length} output(s) need attention.`
  );
  if (args.check && notCurrent > 0) {
    process.exitCode = 1;
  }
}

function readStdin() {
  return new Promise((resolve, reject) => {
    let data = "";
    process.stdin.setEncoding("utf8");
    process.stdin.on("data", (chunk) => (data += chunk));
    process.stdin.on("end", () => resolve(data));
    process.stdin.on("error", reject);
  });
}

// Reads a line from the terminal without echoing it.
function promptHidden(question) {
  const stdin = process.stdin;
  if (!stdin.isTTY) {
    return Promise.reject(new Error("No terminal to prompt in - pipe the token in with --token-stdin."));
  }

  return new Promise((resolve, reject) => {
    process.stdout.write(question);
    stdin.setRawMode(true);
    stdin.setEncoding("utf8");
    stdin.resume();

    let value = "";
    const finish = (error) => {
      stdin.removeListener("data", onData);
      stdin.setRawMode(false);
      stdin.pause();
      process.stdout.write("\n");
      if (error) {
        reject(error);
      } else {
        resolve(value);
      }
    };
    const onData = (chunk) => {
      for (const ch of chunk) {
        if (ch === "\r" || ch === "\n") {
          finish();
          return;
        }
        if (ch === "\u0003" || ch === "\u0004") {
          finish(new Error("Cancelled."));
          return;
        }
        if (ch === "\u007f" || ch === "\b") {
          value = value.slice(0, -1);
        } else if (ch >= " ") {
          value += ch;
        }
      }
    };
    stdin.on("data", onData);
  });
}

function bridgeUrlFor(args) {
  if (args.bridge) {
    return args.bridge;
  }
  try {
    return readAffineConfig(args.positional[0]).bridge;
  } catch {
    return DEFAULT_BRIDGE_URL;
  }
}

async function runLogin(args) {
  const raw = args.tokenStdin
    ? await readStdin()
    : await promptHidden("Authentik API token (input hidden): ");
  const token = raw.trim();
  if (!token) {
    throw new Error("No token entered.");
  }

  if (args.verify) {
    const bridgeUrl = bridgeUrlFor(args);
    const workspaces = await createBridge(bridgeUrl, token).fetchWorkspaces();
    console.log(`Token works: ${workspaces.length} workspace(s) visible on ${bridgeUrl}.`);
  }

  const filePath = saveToken(token);
  console.log(`Saved to ${filePath}`);
  if (process.env[ENV_VAR]) {
    console.warn(`Note: $${ENV_VAR} is set in this shell and takes precedence over the saved token.`);
  }
}

function runLogout() {
  const filePath = deleteToken();
  console.log(filePath ? `Deleted ${filePath}` : "No saved token.");
  if (process.env[ENV_VAR]) {
    console.warn(`Note: $${ENV_VAR} is still set in this shell.`);
  }
}

async function runWorkspaces(args) {
  const bridge = createBridge(bridgeUrlFor(args), requireToken());
  const workspaces = await bridge.fetchWorkspaces();
  if (workspaces.length === 0) {
    console.log("No workspaces visible to this token.");
    return;
  }
  for (const ws of workspaces) {
    console.log(`  ${ws.id}  ${ws.name || "(unnamed)"}`);
  }
  console.log(`\nSet one as the default in sof.toml:\n\n[affine]\nworkspace = "${workspaces[0].id}"`);
}

function toModuleName(name) {
  const words = String(name || "").match(/[A-Za-z0-9]+/g) || [];
  const joined = words.map((w) => w[0].toUpperCase() + w.slice(1)).join("");
  return /^[A-Za-z]/.test(joined) ? joined : `Table${joined}`;
}

async function runDatabases(args) {
  let workspaceId = args.positional[0] || null;
  let config = null;
  if (!workspaceId) {
    try {
      config = readAffineConfig();
    } catch {
      config = null;
    }
    workspaceId = config && config.defaultWorkspace;
  }
  if (!workspaceId) {
    throw new Error("Pass a workspace id, or set [affine] workspace in sof.toml. List them with: sof run affine workspaces");
  }

  const bridge = createBridge(args.bridge || (config ? config.bridge : DEFAULT_BRIDGE_URL), requireToken());
  const databases = await bridge.fetchDatabases(workspaceId);
  if (databases.length === 0) {
    console.log(`No database blocks in workspace ${workspaceId}.`);
    return;
  }

  const sameWorkspace = config && config.defaultWorkspace === workspaceId;
  if (args.toml) {
    for (const db of databases) {
      console.log(`# ${db.name || "(unnamed)"}`);
      console.log("[[affine.sync]]");
      console.log(`table = "${sameWorkspace ? db.id : `${workspaceId}:${db.id}`}"`);
      console.log(`output = "src/ReplicatedStorage/Data/${toModuleName(db.name)}.luau"\n`);
    }
    return;
  }

  for (const db of databases) {
    console.log(`  ${db.id}  ${db.name || "(unnamed)"}`);
  }
  console.log("\nAdd --toml to print them as [[affine.sync]] entries.");
}

const PARSER_PRESET = `"use strict";

// Custom parser for the AFFiNE table synced into the .luau file next to it.
//
// sof run affine picks this up automatically (<name>.parser.js beside
// <name>.luau, or the entry's "parser" key in sof.toml) and gives it the last
// word on what gets written out. Whatever it returns is serialized into the
// Luau module. It may be async.
//
//   data     The table that would otherwise be written. With a title column
//            it is an object keyed by each row's title; without one it is an
//            array of rows in table order. Variable cells are already resolved.
//
//   context  .raw       the decoded bridge payload, exactly as received
//            .columns   [{ id, name, type }, ...] - type is "title", "number",
//                       "checkbox", "select", "variable", ...
//            .rows      the normalized rows as an array, before title keying
//            .title     the table's title in AFFiNE
//            .tableId   "<workspaceId>:<blockId>"
//            .output    absolute path of the .luau file being written
//            .unresolvedVariables  descriptions of any {{Group.Name}} the
//                                  bridge could not resolve
//
// Throwing aborts this table's sync and is reported, so it is safe to assert
// on the shape you expect.

module.exports = function transform(data, context) {
  // Select and multi-select cells arrive as raw AFFiNE option ids rather than
  // the labels shown in the UI. Map them like this:
  //
  // const CLASS_LABELS = {
  //   "vqK-InD-bf": "Warrior",
  //   "UXapvDJj-6": "Mage",
  // };
  // for (const row of Object.values(data)) {
  //   if (CLASS_LABELS[row.Class]) {
  //     row.Class = CLASS_LABELS[row.Class];
  //   }
  // }

  // Other things this is the right place for:
  //   * dropping columns the game does not need
  //   * renaming "Max Health" to MaxHealth so it can be indexed with a dot
  //   * coercing "10" to 10, or splitting a comma-separated cell into an array
  //   * asserting required columns exist before the data reaches the game

  return data;
};
`;

function runParser(args) {
  const target = args.positional[0];
  if (!target) {
    throw new Error("Usage: sof run affine parser <output.luau> [config]");
  }

  let config = null;
  try {
    config = readAffineConfig(args.positional[1]);
  } catch {
    config = null;
  }

  const baseDirectory = config ? config.configDirectory : process.cwd();
  const outputPath = path.resolve(baseDirectory, target);
  const entry = config && config.entries.find((e) => e.outputPath.toLowerCase() === outputPath.toLowerCase());

  if (entry && entry.parserPath && fs.existsSync(entry.parserPath)) {
    console.log(`${relative(baseDirectory, entry.outputPath)} already has a parser: ${relative(baseDirectory, entry.parserPath)}`);
    return;
  }

  const parserPath = entry && entry.parserExplicit ? entry.parserPath : autoParserPaths(outputPath)[0];
  fs.mkdirSync(path.dirname(parserPath), { recursive: true });
  fs.writeFileSync(parserPath, PARSER_PRESET, { encoding: "utf8", flag: "wx" });
  console.log(`Created ${relative(baseDirectory, parserPath)}`);
  if (!entry) {
    console.warn(`Note: no [[affine.sync]] entry writes ${relative(baseDirectory, outputPath)} yet.`);
  }
}

async function runAffine(argv) {
  const args = parseArgs(argv);
  if (args.help) {
    console.log(HELP_TEXT);
    return;
  }

  switch (args.command) {
    case "sync":
      return runSync(args);
    case "status":
      return runStatus(args);
    case "login":
      return runLogin(args);
    case "logout":
      return runLogout();
    case "workspaces":
      return runWorkspaces(args);
    case "databases":
      return runDatabases(args);
    case "parser":
      return runParser(args);
  }
}

module.exports = { runAffine };
