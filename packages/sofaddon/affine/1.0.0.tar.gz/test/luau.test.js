"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");

const { fingerprint, serializeLuau, formatG17 } = require("../src/affine/luau");

// parity-expected.json is what the AffineSync Studio plugin's own
// serializeLuauValue/fingerprint produced for parity-fixtures.json (run in
// Studio after HttpService:JSONDecode). If these drift, the CLI and the plugin
// disagree about whether upstream changed.
const fixtures = require("./parity-fixtures.json");
const expected = require("./parity-expected.json");

test("fingerprints match the Studio plugin", () => {
  fixtures.forEach((value, i) => assert.equal(fingerprint(value), expected[i].fp, `fixture #${i + 1}`));
});

test("serialized source matches the Studio plugin byte for byte", () => {
  // JSON null keys do not exist once decoded in Luau.
  fixtures.forEach((value, i) => assert.equal(serializeLuau(value), expected[i].src, `fixture #${i + 1}`));
});

test("numbers print like Luau tostring", () => {
  // Values captured from tostring() in Studio.
  const cases = [
    [1e-7, "1e-07"],
    [1e-6, "0.000001"],
    [1.5e-6, "0.0000015"],
    [9.99e-7, "9.99e-07"],
    [1.25e-8, "1.25e-08"],
    [1e-100, "1e-100"],
    [9.99e20, "999000000000000000000"],
    [1e21, "1e+21"],
    [1.5e21, "1.5e+21"],
    [1e100, "1e+100"],
    [5e-324, "5e-324"],
    [1.7976931348623157e308, "1.7976931348623157e+308"],
    [2 ** 63, "9223372036854776000"],
    [-0, "-0"],
    [12345.678, "12345.678"],
  ];
  for (const [n, text] of cases) {
    assert.equal(serializeLuau(n), text, String(n));
  }
});

test("%.17g matches C", () => {
  assert.equal(formatG17(0.1), "0.10000000000000001");
  assert.equal(formatG17(1e17), "1e+17");
  assert.equal(formatG17(1e16), "10000000000000000");
  assert.equal(formatG17(1e-5), "1.0000000000000001e-05");
  assert.equal(formatG17(0.0001), "0.0001");
  assert.equal(formatG17(100), "100");
  assert.equal(formatG17(-2.5e-10), "-2.5000000000000002e-10");
});

test("strings quote like Luau %q", () => {
  let s = "";
  for (let i = 0; i < 32; i++) {
    s += String.fromCharCode(i);
  }
  s += "\x7fé";
  // Byte sequence captured from string.format("%q", s) in Studio.
  const studio = [
    34, 92, 48, 48, 48, 1, 2, 3, 4, 5, 6, 7, 8, 9, 92, 10, 11, 12, 92, 114, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23,
    24, 25, 26, 27, 28, 29, 30, 31, 127, 195, 169, 34,
  ];
  assert.deepEqual([...Buffer.from(serializeLuau(s), "utf8")], studio);
});

test("a cyclic parser result fails cleanly", () => {
  const cyclic = {};
  cyclic.self = cyclic;
  assert.throws(() => serializeLuau(cyclic), /nests deeper than 64/);
});
